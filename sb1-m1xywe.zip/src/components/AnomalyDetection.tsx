import React from 'react';
import { AlertTriangle, CheckCircle } from 'lucide-react';

const anomalies = [
  { id: 1, date: '2023-06-15', type: 'Sudden Drop', station: 'Station A', status: 'Resolved' },
  { id: 2, date: '2023-06-14', type: 'No Data', station: 'Station B', status: 'Pending' },
  { id: 3, date: '2023-06-13', type: 'Unusual Spike', station: 'Station C', status: 'Investigating' },
];

const AnomalyDetection: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Anomaly Detection</h1>
      
      <div className="bg-white p-4 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-4">Recent Anomalies</h2>
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Station</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {anomalies.map((anomaly) => (
              <tr key={anomaly.id}>
                <td className="px-6 py-4 whitespace-nowrap">{anomaly.date}</td>
                <td className="px-6 py-4 whitespace-nowrap">{anomaly.type}</td>
                <td className="px-6 py-4 whitespace-nowrap">{anomaly.station}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    anomaly.status === 'Resolved' ? 'bg-green-100 text-green-800' : 
                    anomaly.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {anomaly.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <a href="#" className="text-indigo-600 hover:text-indigo-900">View</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Anomaly Statistics</h2>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span>Total Anomalies (Last 30 days):</span>
              <span className="font-semibold">15</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Resolved:</span>
              <span className="font-semibold text-green-600">10</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Pending:</span>
              <span className="font-semibold text-yellow-600">3</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Investigating:</span>
              <span className="font-semibold text-red-600">2</span>
            </div>
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">System Status</h2>
          <div className="space-y-2">
            <div className="flex items-center">
              <CheckCircle className="text-green-500 mr-2" />
              <span>Anomaly Detection System: Operational</span>
            </div>
            <div className="flex items-center">
              <AlertTriangle className="text-yellow-500 mr-2" />
              <span>2 Stations Require Maintenance</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnomalyDetection;