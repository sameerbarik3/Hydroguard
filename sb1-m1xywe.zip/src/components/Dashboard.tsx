import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { AlertCircle, Battery, WifiOff } from 'lucide-react';

const data = [
  { name: 'Jan', waterLevel: 4000 },
  { name: 'Feb', waterLevel: 3000 },
  { name: 'Mar', waterLevel: 2000 },
  { name: 'Apr', waterLevel: 2780 },
  { name: 'May', waterLevel: 1890 },
  { name: 'Jun', waterLevel: 2390 },
];

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-2">System Health</h2>
          <div className="flex items-center text-green-500">
            <div className="w-4 h-4 bg-green-500 rounded-full mr-2"></div>
            Operational
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-2">Active Alerts</h2>
          <div className="space-y-2">
            <div className="flex items-center text-yellow-500">
              <Battery className="mr-2" /> Low Battery: 2 Stations
            </div>
            <div className="flex items-center text-red-500">
              <WifiOff className="mr-2" /> No Data: 1 Station
            </div>
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-2">Recent Anomalies</h2>
          <div className="flex items-center text-orange-500">
            <AlertCircle className="mr-2" /> 3 Detected in Last 24h
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-4">Water Level Trend</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="waterLevel" fill="#3b82f6" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Dashboard;