import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import WaterLevelMonitoring from './components/WaterLevelMonitoring';
import AnomalyDetection from './components/AnomalyDetection';
import MapView from './components/MapView';
import Login from './components/Login';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/water-levels" element={<WaterLevelMonitoring />} />
            <Route path="/anomalies" element={<AnomalyDetection />} />
            <Route path="/map" element={<MapView />} />
            <Route path="/login" element={<Login />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;